/*! @name videojs-quality-selector-plugin @version 1.0.2 @license Apache-2.0 */
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('video.js')) :
  typeof define === 'function' && define.amd ? define(['video.js'], factory) :
  (global.videojsQualitySelectorPlugin = factory(global.videojs));
}(this, (function (videojs) { 'use strict';
  videojs = videojs && videojs.hasOwnProperty('default') ? videojs['default'] : videojs;
  function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    subClass.__proto__ = superClass;
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  var version = "1.0.2";
  var Plugin = videojs.getPlugin('plugin');
  var Menu = videojs.getComponent('Menu');
  var MenuButton = videojs.getComponent('MenuButton');
  var MenuItem = videojs.getComponent('MenuItem'); // Default options for the plugin.
  var defaults = {};
  /**
   * Video quality item.
   */
  var VideoQualityItem =
  /*#__PURE__*/
  function (_MenuItem) {
    _inheritsLoose(VideoQualityItem, _MenuItem);
    function VideoQualityItem(player, options) {
      var _this;
      _this = _MenuItem.call(this, player, options) || this;
      _this.updateSelectMenu = options.updateSelectMenu;
      return _this;
    }
    var _proto = VideoQualityItem.prototype;
    _proto.handleClick = function handleClick() {
      this.updateSelectMenu(this.options_.identify);
      this.player().qualitySelector().changeVideoQuality(this.options_.identify);
    };
    return VideoQualityItem;
  }(MenuItem);
  var QualityMenu =
  /*#__PURE__*/
  function (_Menu) {
    _inheritsLoose(QualityMenu, _Menu);
    function QualityMenu(player, options) {
      return _Menu.call(this, player, options) || this;
    }
    return QualityMenu;
  }(Menu);
  var QualitySelectorMenuButton =
  /*#__PURE__*/
  function (_MenuButton) {
    _inheritsLoose(QualitySelectorMenuButton, _MenuButton);
    function QualitySelectorMenuButton(player, options) {
      var _this2;
      _this2 = _MenuButton.call(this, player, options) || this;
      _this2.addClass('vjs-quality-selector-menu');
      _this2.bindUpdateSelectMenu = _this2.updateSelectMenu.bind(_assertThisInitialized(_assertThisInitialized(_this2)));
      _this2.createItems();
      return _this2;
    }
    var _proto2 = QualitySelectorMenuButton.prototype;
    _proto2.updateSelectMenu = function updateSelectMenu(identify) {
      var player = this.player();
      var qualityLevels = player.options_.qualityLevels || [];
      var menuItems = this.children()[1].children();
      for (var _iterator = qualityLevels.entries(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
        var _ref;
        if (_isArray) {
          if (_i >= _iterator.length) break;
          _ref = _iterator[_i++];
        } else {
          _i = _iterator.next();
          if (_i.done) break;
          _ref = _i.value;
        }
        var _ref2 = _ref,
            index = _ref2[0],
            level = _ref2[1];
        if (menuItems[index].el().classList.contains('vjs-selected')) {
          menuItems[index].el().classList.remove('vjs-selected');
        }
        if (level.identify === identify) {
          this.el().getElementsByClassName('vjs-quality-selector-btn')[0].textContent = level.label;
          menuItems[index].el().classList.add('vjs-selected');
        }
      }
    };
    _proto2.createMenu = function createMenu() {
      var _this3 = this;
      var menu = new QualityMenu(this.player, this.options_);
      var player = this.player();
      var qualityLevels = player.options_.qualityLevels || [];
      var hasAuto = false;
      var fallbackItem = null;
      for (var _iterator2 = qualityLevels, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
        var _ref3;
        if (_isArray2) {
          if (_i2 >= _iterator2.length) break;
          _ref3 = _iterator2[_i2++];
        } else {
          _i2 = _iterator2.next();
          if (_i2.done) break;
          _ref3 = _i2.value;
        }
        var item = _ref3;
        if (item.label === 'auto') {
          hasAuto = true;
          break;
        } else if (!fallbackItem) {
          fallbackItem = item;
        }
      }
      qualityLevels.forEach(function (item) {
        var menuItem = new VideoQualityItem(player, {
          label: item.label,
          identify: item.identify,
          updateSelectMenu: videojs.bind(_this3, _this3.updateSelectMenu)
        });
        if (hasAuto) {
          _this3.el().innerHTML = "<span class='vjs-quality-selector-btn'>" + item.label + "</span>";
          if (player.currentSrc().length === 0) {
            player.src(item.src);
          }
          menuItem.addClass('vjs-selected');
        } else if (item.src === fallbackItem.src) {
          _this3.el().innerHTML = "<span class='vjs-quality-selector-btn'>" + fallbackItem.label + "</span>";
          if (player.currentSrc().length === 0) {
            player.src(fallbackItem.src);
          }
          menuItem.addClass('vjs-selected');
        }
        menu.addItem(menuItem);
      });
      return menu;
    };
    return QualitySelectorMenuButton;
  }(MenuButton);
  /**
   * An advanced Video.js plugin. For more information on the API
   *
   * See: https://blog.videojs.com/feature-spotlight-advanced-plugins/
   */
  var QualitySelector =
  /*#__PURE__*/
  function (_Plugin) {
    _inheritsLoose(QualitySelector, _Plugin);
    /**
     * Create a QualitySelector plugin instance.
     *
     * @param  {Player} player
     *         A Video.js Player instance.
     *
     * @param  {Object} [options]
     *         An optional options object.
     *
     *         While not a core part of the Video.js plugin architecture, a
     *         second argument of options is a convenient way to accept inputs
     *         from your plugin's caller.
     */
    function QualitySelector(player, options) {
      var _this4;
      // the parent class will add player under this.player
      _this4 = _Plugin.call(this, player) || this;
      _this4.options = videojs.mergeOptions(defaults, options);
      _this4.player.ready(function () {
        _this4.player.addClass('vjs-quality-selector');
        _this4.player.getChild('controlBar').addChild('qualityMenuButton', {}, _this4.player.children().length - 1);
      });
      return _this4;
    }
    /**
     * Change video quality.
     */
    var _proto3 = QualitySelector.prototype;
    _proto3.changeVideoQuality = function changeVideoQuality(identify) {
      var player = this.player;
      var currentPlayAt = player.currentTime();
      var src;
      var qualityAry = player.options_.qualityLevels || [];
      if (qualityAry.length !== 0) {
        for (var _iterator3 = qualityAry, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
          var _ref4;
          if (_isArray3) {
            if (_i3 >= _iterator3.length) break;
            _ref4 = _iterator3[_i3++];
          } else {
            _i3 = _iterator3.next();
            if (_i3.done) break;
            _ref4 = _i3.value;
          }
          var level = _ref4;
          if (level.identify === identify) {
            src = level.src;
            break;
          }
        }
        if (typeof src !== 'undefined' && player.currentSrc() !== src) {
          player.src({
            src: src
          });
          player.load();
          player.currentTime(currentPlayAt);
          if (!player.ended()) {
            player.play();
          }
        }
      }
    };
    return QualitySelector;
  }(Plugin); // Define default values for the plugin's `state` object here.
  QualitySelector.defaultState = {}; // Include the version number.
  QualitySelector.VERSION = version; // Register menu button.
  videojs.registerComponent('qualityMenuButton', QualitySelectorMenuButton); // Register the plugin with video.js.
  videojs.registerPlugin('qualitySelector', QualitySelector);
  return QualitySelector;
})));
